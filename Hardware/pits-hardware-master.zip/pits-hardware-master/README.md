Hardware for the Pi In The Sky Project.

These files are done in Cadsoft Eagle 6.4

